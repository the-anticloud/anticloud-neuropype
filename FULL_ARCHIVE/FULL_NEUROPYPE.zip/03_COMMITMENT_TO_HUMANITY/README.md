# 03 Commitment To Humanity

**Project:** NEUROPYPE
**Upstream:** https://github.com/nicedoc/neuropype

Content specific to NEUROPYPE in category BRAIN_COMPUTER_INTERFACE.
